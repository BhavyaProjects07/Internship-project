
"use client";

import { useCallback, useEffect, useState } from "react";
import { Puck } from "@puckeditor/core";
import puckConfig from "./puck-config";

const API_URL = (
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api"
).replace(/\/+$/, "");

const createEmptyDocument = () => ({
  content: [],
  root: {
    props: {},
  },
});

export default function PuckEditorClient({
  templateId,
  pageId,
  getToken,
}) {
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState(null);

  useEffect(() => {
    let cancelled = false;

    async function loadDocument() {
      setData(null);
      setError("");
      setSavedAt(null);

      try {
        const token = await getToken();

        if (!token) {
          throw new Error("Authentication token unavailable.");
        }

        const response = await fetch(
          `${API_URL}/templates/admin/${encodeURIComponent(
            templateId
          )}/pages/${encodeURIComponent(pageId)}/editor-data`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
            cache: "no-store",
          }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
          throw new Error(
            result.message || "Unable to load page document."
          );
        }

        const document =
          result.data?.editorData ?? createEmptyDocument();

        if (!cancelled) {
          setData(document);
        }
      } catch (err) {
        if (!cancelled) {
          setError(
            err.message || "Unable to load the page editor."
          );
        }
      }
    }

    if (templateId && pageId && getToken) {
      loadDocument();
    }

    return () => {
      cancelled = true;
    };
  }, [templateId, pageId, getToken]);

  const saveDocument = useCallback(
    async (document) => {
      if (saving) return;

      setSaving(true);
      setError("");

      try {
        const token = await getToken();

        if (!token) {
          throw new Error("Authentication token unavailable.");
        }

        const response = await fetch(
          `${API_URL}/templates/admin/${encodeURIComponent(
            templateId
          )}/pages/${encodeURIComponent(pageId)}/editor-data`,
          {
            method: "PUT",
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              editorData: document,
            }),
          }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
          throw new Error(
            result.message || "Unable to save page document."
          );
        }

        setData(result.data.editorData ?? document);
        setSavedAt(new Date().toLocaleTimeString());
      } catch (err) {
        setError(err.message || "Unable to save the page.");
      } finally {
        setSaving(false);
      }
    },
    [templateId, pageId, getToken, saving]
  );

  if (error && !data) {
    return (
      <div
        role="alert"
        className="m-4 space-y-3 rounded-lg border border-red-300 p-4"
      >
        <p>{error}</p>
        <button
          type="button"
          className="rounded-md border px-3 py-2"
          onClick={() => window.location.reload()}
        >
          Retry
        </button>
      </div>
    );
  }

  if (!data) {
    return (
      <p className="p-6" role="status">
        Loading page editor…
      </p>
    );
  }

  return (
    <div className="space-y-3">
      <div
        className="flex flex-wrap items-center justify-between gap-3 px-3"
        aria-live="polite"
      >
        <p className="text-sm text-gray-600">
          {saving
            ? "Saving page…"
            : savedAt
              ? `Last saved at ${savedAt}`
              : "Use Publish to save your changes."}
        </p>
      </div>

      {error && (
        <div
          role="alert"
          className="mx-3 rounded-md border border-red-300 p-3 text-sm text-red-700"
        >
          {error}
        </div>
      )}

      <Puck
        config={puckConfig}
        data={data}
        onPublish={saveDocument}
      />
    </div>
  );
}
