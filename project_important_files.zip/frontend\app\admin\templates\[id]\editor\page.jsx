
"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useAuth } from "@clerk/nextjs";
import { useParams, useRouter } from "next/navigation";

const API_URL = (
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api"
).replace(/\/+$/, "");

const SECTION_LIBRARY = [
  { type: "header", name: "Header", group: "Basic", description: "Navigation and brand" },
  { type: "hero", name: "Hero", group: "Basic", description: "Headline and call to action" },
  { type: "about", name: "About", group: "Content", description: "Introduce your brand" },
  { type: "features", name: "Features", group: "Content", description: "Highlight key benefits" },
  { type: "services", name: "Services", group: "Business", description: "Showcase your services" },
  { type: "gallery", name: "Gallery", group: "Media", description: "Display images or projects" },
  { type: "testimonials", name: "Testimonials", group: "Content", description: "Customer feedback" },
  { type: "pricing", name: "Pricing", group: "Business", description: "Plans and pricing" },
  { type: "faq", name: "FAQ", group: "Content", description: "Answer common questions" },
  { type: "contact", name: "Contact", group: "Business", description: "Contact details and CTA" },
  { type: "footer", name: "Footer", group: "Basic", description: "Links and copyright" },
];

const DEFAULT_CONTENT = {
  header: {
    logo: "STUDIO",
    links: ["Work", "About", "Services", "Contact"],
    buttonText: "Get in touch",
  },
  hero: {
    eyebrow: "CREATIVE STUDIO",
    heading: "Designing digital experiences that move people.",
    description: "We build thoughtful digital experiences for ambitious brands and forward-thinking businesses.",
    buttonText: "Explore our work",
    buttonLink: "#work",
    image: "",
  },
  about: {
    heading: "A little about us",
    description: "We combine strategy, design, and technology to build meaningful digital experiences.",
    image: "",
  },
  features: {
    heading: "What makes us different",
    description: "Everything you need to build a stronger digital presence.",
  },
  services: {
    heading: "What we do",
    description: "Strategy, design, and development tailored to your business.",
  },
  gallery: {
    heading: "Selected work",
    description: "A selection of our latest projects.",
    image: "",
  },
  testimonials: {
    heading: "Kind words from our clients",
    description: "Trusted by teams who care about great work.",
  },
  pricing: {
    heading: "Simple, transparent pricing",
    description: "Choose the plan that works for you.",
  },
  faq: {
    heading: "Frequently asked questions",
    description: "Answers to the things people ask us most.",
  },
  contact: {
    heading: "Let's make something great",
    description: "Tell us about your project. We'd love to hear from you.",
    buttonText: "Contact us",
    buttonLink: "mailto:hello@example.com",
  },
  footer: {
    logo: "STUDIO",
    description: "Thoughtful digital experiences for ambitious brands.",
  },
};

const INITIAL_CONFIG = {
  background: "#ffffff",
  textColor: "#171717",
  accentColor: "#6741ff",
  alignment: "left",
  padding: 64,
  radius: 16,
};

function createSection(type, order) {
  const definition = SECTION_LIBRARY.find((item) => item.type === type);

  return {
    id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    type,
    order,
    content: { ...(DEFAULT_CONTENT[type] || {}) },
    config: { ...INITIAL_CONFIG },
    _local: true,
    _label: definition?.name || type,
  };
}

function getContent(section, key, fallback = "") {
  return typeof section.content?.[key] === "string"
    ? section.content[key]
    : fallback;
}

export default function TemplateEditorPage() {
  const { id } = useParams();
  const router = useRouter();
  const { isLoaded, isSignedIn, getToken } = useAuth();

  const [template, setTemplate] = useState(null);
  const [activePageId, setActivePageId] = useState("");
  const [selectedSectionId, setSelectedSectionId] = useState("");
  const [search, setSearch] = useState("");
  const [sectionGroup, setSectionGroup] = useState("All");
  const [device, setDevice] = useState("desktop");
  const [inspectorTab, setInspectorTab] = useState("content");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [dirty, setDirty] = useState(false);
  const [showLibrary, setShowLibrary] = useState(true);

  const loadTemplate = useCallback(async () => {
    if (!id) return;

    setLoading(true);
    setError("");

    try {
      const token = await getToken();

      if (!token) throw new Error("Your session has expired. Please sign in again.");

      const response = await fetch(`${API_URL}/templates/admin/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
        cache: "no-store",
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.message || "Failed to load template.");
      }

      const loaded = result.data;

      loaded.pages = (loaded.pages || []).map((page) => ({
        ...page,
        sections: (page.sections || []).map((section) => ({
          ...section,
          content: section.content || {},
          config: { ...INITIAL_CONFIG, ...(section.config || {}) },
        })),
      }));

      setTemplate(loaded);
      setActivePageId((current) => current || loaded.pages?.[0]?.id || "");
      setDirty(false);
    } catch (err) {
      setError(err.message || "Failed to load template.");
    } finally {
      setLoading(false);
    }
  }, [id, getToken]);

  useEffect(() => {
    if (isLoaded && isSignedIn) loadTemplate();
    if (isLoaded && !isSignedIn) {
      setError("Please sign in to edit templates.");
      setLoading(false);
    }
  }, [isLoaded, isSignedIn, loadTemplate]);

  const activePage = useMemo(
    () => template?.pages?.find((page) => page.id === activePageId),
    [template, activePageId]
  );

  const sections = activePage?.sections || [];

  const selectedSection = sections.find(
    (section) => section.id === selectedSectionId
  );

  const filteredLibrary = SECTION_LIBRARY.filter((item) => {
    const matchesSearch =
      item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.description.toLowerCase().includes(search.toLowerCase());

    return matchesSearch &&
      (sectionGroup === "All" || item.group === sectionGroup);
  });

  function updateSection(sectionId, updater) {
    setTemplate((current) => ({
      ...current,
      pages: current.pages.map((page) =>
        page.id !== activePageId
          ? page
          : {
              ...page,
              sections: page.sections.map((section) =>
                section.id === sectionId ? updater(section) : section
              ),
            }
      ),
    }));
    setDirty(true);
  }

  function addSection(type) {
    const newSection = createSection(type, sections.length);

    setTemplate((current) => ({
      ...current,
      pages: current.pages.map((page) =>
        page.id !== activePageId
          ? page
          : { ...page, sections: [...page.sections, newSection] }
      ),
    }));

    setSelectedSectionId(newSection.id);
    setInspectorTab("content");
    setDirty(true);
  }

  function moveSection(sectionId, direction) {
    const index = sections.findIndex((section) => section.id === sectionId);
    const nextIndex = index + direction;

    if (index < 0 || nextIndex < 0 || nextIndex >= sections.length) return;

    const reordered = [...sections];
    [reordered[index], reordered[nextIndex]] = [
      reordered[nextIndex],
      reordered[index],
    ];

    setTemplate((current) => ({
      ...current,
      pages: current.pages.map((page) =>
        page.id === activePageId
          ? {
              ...page,
              sections: reordered.map((section, order) => ({ ...section, order })),
            }
          : page
      ),
    }));

    setDirty(true);
  }

  function duplicateSection(sectionId) {
    const source = sections.find((section) => section.id === sectionId);
    if (!source) return;

    const duplicate = {
      ...source,
      id: `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      content: { ...source.content },
      config: { ...source.config },
      _local: true,
    };

    const index = sections.findIndex((section) => section.id === sectionId);
    const reordered = [...sections];
    reordered.splice(index + 1, 0, duplicate);

    setTemplate((current) => ({
      ...current,
      pages: current.pages.map((page) =>
        page.id === activePageId
          ? {
              ...page,
              sections: reordered.map((section, order) => ({ ...section, order })),
            }
          : page
      ),
    }));

    setSelectedSectionId(duplicate.id);
    setDirty(true);
  }

  function deleteSection(sectionId) {
    setTemplate((current) => ({
      ...current,
      pages: current.pages.map((page) =>
        page.id === activePageId
          ? {
              ...page,
              sections: page.sections
                .filter((section) => section.id !== sectionId)
                .map((section, order) => ({ ...section, order })),
            }
          : page
      ),
    }));

    if (selectedSectionId === sectionId) setSelectedSectionId("");
    setDirty(true);
  }

  function updateContent(key, value) {
    if (!selectedSection) return;

    updateSection(selectedSection.id, (section) => ({
      ...section,
      content: { ...section.content, [key]: value },
    }));
  }

  function updateConfig(key, value) {
    if (!selectedSection) return;

    updateSection(selectedSection.id, (section) => ({
      ...section,
      config: { ...section.config, [key]: value },
    }));
  }

  if (loading) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#f7f8fc] text-sm text-gray-500">
        Loading Studio…
      </main>
    );
  }

  if (error || !template) {
    return (
      <main className="min-h-screen bg-[#f7f8fc] p-8">
        <div className="mx-auto max-w-xl rounded-2xl border border-red-200 bg-white p-8">
          <h1 className="text-xl font-bold text-gray-950">Unable to open template</h1>
          <p className="mt-3 text-sm text-red-700">{error || "Template not found."}</p>
          <button onClick={() => router.push("/admin/templates")} className="mt-6 rounded-xl bg-gray-950 px-4 py-3 text-sm font-semibold text-white">
            Back to templates
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="flex h-screen flex-col overflow-hidden bg-[#f5f6fa] text-gray-950">
      <header className="z-30 flex min-h-[66px] flex-wrap items-center justify-between gap-3 border-b border-gray-200 bg-white px-4 py-3 lg:px-6">
        <div className="flex items-center gap-4">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-600 text-lg font-bold text-white shadow-sm">
            S
          </div>
          <div>
            <button onClick={() => router.push("/admin/templates")} className="text-xs text-gray-500 hover:text-gray-900">
              Templates <span className="mx-1">/</span>
              <span className="text-gray-800">{template.name}</span>
            </button>
            <div className="mt-1 flex items-center gap-2">
              <span className="text-sm font-bold">Studio</span>
              <span className="rounded-full bg-violet-50 px-2.5 py-1 text-[11px] font-semibold text-violet-700">
                {dirty ? "● Unsaved changes" : "● Draft · Saved"}
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 rounded-xl bg-gray-100 p-1">
          {[
            ["desktop", "Desktop"],
            ["tablet", "Tablet"],
            ["mobile", "Mobile"],
          ].map(([value, label]) => (
            <button
              key={value}
              onClick={() => setDevice(value)}
              className={`rounded-lg px-3 py-2 text-xs font-medium transition ${device === value ? "bg-white text-violet-700 shadow-sm" : "text-gray-500 hover:text-gray-900"}`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.alert("Preview mode will be connected to the shared renderer next.")}
            className="rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-semibold hover:bg-gray-50"
          >
            Preview
          </button>
          <button
            onClick={() => window.alert("Database saving and publishing endpoints are the next backend step. Your current edits are local only.")}
            className="rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-violet-700"
          >
            Publish
          </button>
        </div>
      </header>

      <div className="grid min-h-0 flex-1 grid-cols-[54px_minmax(0,1fr)] lg:grid-cols-[64px_286px_minmax(0,1fr)_300px]">
        <nav className="flex flex-col items-center gap-2 border-r border-gray-200 bg-white py-4">
          {[
            ["▦", "Sections", true],
            ["▤", "Pages", false],
            ["◉", "Theme", false],
            ["⚙", "Settings", false],
          ].map(([symbol, label, active]) => (
            <button
              key={label}
              title={label}
              onClick={() => {
                if (label === "Sections") setShowLibrary(true);
                else if (label === "Pages") window.alert("Page management is the next milestone.");
                else window.alert(`${label} controls are coming in a later milestone.`);
              }}
              className={`flex w-12 flex-col items-center gap-1 rounded-xl py-3 text-[10px] font-medium ${active ? "bg-violet-50 text-violet-700" : "text-gray-500 hover:bg-gray-50"}`}
            >
              <span className="text-lg">{symbol}</span>
              {label}
            </button>
          ))}
        </nav>

        <aside className="hidden min-h-0 overflow-y-auto border-r border-gray-200 bg-white p-4 lg:block">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-sm font-bold">Add sections</h2>
              <p className="mt-1 text-xs leading-5 text-gray-500">Build your page one section at a time.</p>
            </div>
            <span className="rounded-lg bg-violet-50 px-2 py-1 text-xs font-semibold text-violet-700">
              {sections.length}
            </span>
          </div>

          <div className="relative mt-5">
            <span className="absolute left-3 top-2.5 text-gray-400">⌕</span>
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search sections…"
              className="w-full rounded-xl border border-gray-200 py-2.5 pl-9 pr-3 text-xs outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
            />
          </div>

          <div className="mt-4 flex flex-wrap gap-1.5">
            {["All", "Basic", "Content", "Media", "Business"].map((group) => (
              <button
                key={group}
                onClick={() => setSectionGroup(group)}
                className={`rounded-lg px-2.5 py-1.5 text-[11px] font-medium ${sectionGroup === group ? "bg-violet-600 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"}`}
              >
                {group}
              </button>
            ))}
          </div>

          <div className="mt-4 space-y-2">
            {filteredLibrary.map((item) => (
              <button
                key={item.type}
                onClick={() => addSection(item.type)}
                className="group flex w-full items-center gap-3 rounded-xl border border-gray-200 p-3 text-left transition hover:border-violet-300 hover:bg-violet-50/50"
              >
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-100 to-indigo-50 text-lg font-bold text-violet-700">
                  {item.name.slice(0, 1)}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-xs font-semibold">{item.name}</span>
                  <span className="mt-1 block text-[10px] leading-4 text-gray-500">{item.description}</span>
                </span>
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-violet-50 text-sm text-violet-700 group-hover:bg-violet-600 group-hover:text-white">+</span>
              </button>
            ))}
            {filteredLibrary.length === 0 && (
              <p className="py-8 text-center text-xs text-gray-500">No sections match your search.</p>
            )}
          </div>
        </aside>

        <section className="min-w-0 overflow-y-auto p-3 sm:p-5 lg:p-7">
          <div className="mx-auto w-full transition-all duration-200" style={{ maxWidth: device === "desktop" ? 1100 : device === "tablet" ? 760 : 390 }}>
            <div className="mb-3 flex items-center justify-between rounded-xl border border-gray-200 bg-white px-4 py-3 shadow-sm">
              <div className="min-w-0">
                <p className="truncate text-xs font-semibold">{activePage?.name || "No page selected"}</p>
                <p className="mt-1 text-[10px] text-gray-500">/{activePage?.slug || ""} · {device} preview</p>
              </div>
              <select
                value={activePageId}
                onChange={(event) => {
                  setActivePageId(event.target.value);
                  setSelectedSectionId("");
                }}
                className="max-w-36 rounded-lg border border-gray-200 bg-white px-2 py-2 text-xs"
              >
                {(template.pages || []).map((page) => (
                  <option key={page.id} value={page.id}>{page.name}</option>
                ))}
              </select>
            </div>

            <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white shadow-sm">
              {sections.length === 0 ? (
                <div className="flex min-h-[480px] flex-col items-center justify-center px-6 py-16 text-center">
                  <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-50 text-2xl text-violet-700">✦</div>
                  <h2 className="mt-5 text-xl font-bold">Start building something beautiful</h2>
                  <p className="mt-2 max-w-sm text-sm leading-6 text-gray-500">Add your first section from the library. Select it to edit the content and styling here.</p>
                  <button onClick={() => addSection("hero")} className="mt-6 rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white hover:bg-violet-700">
                    + Add hero section
                  </button>
                </div>
              ) : (
                sections.map((section, index) => {
                  const definition = SECTION_LIBRARY.find((item) => item.type === section.type);
                  const content = section.content || {};
                  const config = { ...INITIAL_CONFIG, ...(section.config || {}) };
                  const selected = section.id === selectedSectionId;

                  return (
                    <section
                      key={section.id}
                      onClick={() => setSelectedSectionId(section.id)}
                      className={`group relative cursor-pointer border-b last:border-b-0 ${selected ? "z-10 outline outline-2 outline-violet-500 outline-offset-[-2px]" : "border-gray-100 hover:outline hover:outline-1 hover:outline-violet-200"}`}
                      style={{
                        background: config.background,
                        color: config.textColor,
                        textAlign: config.alignment,
                        padding: `${Math.min(Number(config.padding) || 64, 120)}px clamp(20px, 5vw, 64px)`,
                        borderRadius: `${config.radius}px`,
                      }}
                    >
                      {selected && (
                        <div className="absolute right-3 top-3 z-10 flex items-center gap-1 rounded-lg border border-violet-200 bg-white p-1 shadow-sm">
                          <button title="Move up" disabled={index === 0} onClick={(event) => { event.stopPropagation(); moveSection(section.id, -1); }} className="rounded-md px-2 py-1 text-xs text-gray-600 hover:bg-gray-100 disabled:opacity-30">↑</button>
                          <button title="Move down" disabled={index === sections.length - 1} onClick={(event) => { event.stopPropagation(); moveSection(section.id, 1); }} className="rounded-md px-2 py-1 text-xs text-gray-600 hover:bg-gray-100 disabled:opacity-30">↓</button>
                          <button title="Duplicate" onClick={(event) => { event.stopPropagation(); duplicateSection(section.id); }} className="rounded-md px-2 py-1 text-xs text-gray-600 hover:bg-gray-100">⧉</button>
                          <button title="Delete" onClick={(event) => { event.stopPropagation(); deleteSection(section.id); }} className="rounded-md px-2 py-1 text-xs text-red-600 hover:bg-red-50">×</button>
                        </div>
                      )}

                      <div className="mx-auto max-w-3xl">
                        <p className="mb-3 text-[10px] font-bold uppercase tracking-[0.2em]" style={{ color: config.accentColor }}>
                          {getContent(section, "eyebrow", definition?.name || section.type)}
                        </p>

                        <h2 className="text-3xl font-bold leading-tight tracking-tight sm:text-4xl" style={{ color: config.textColor }}>
                          {getContent(section, "heading", definition?.name || "Section heading")}
                        </h2>

                        {getContent(section, "description") && (
                          <p className="mx-auto mt-4 max-w-2xl text-sm leading-7 opacity-75 sm:text-base">
                            {getContent(section, "description")}
                          </p>
                        )}

                        {getContent(section, "image") && (
                          <img
                            src={getContent(section, "image")}
                            alt=""
                            className="mx-auto mt-6 max-h-80 w-full rounded-xl object-cover"
                          />
                        )}

                        {getContent(section, "buttonText") && (
                          <span
                            className="mt-6 inline-flex rounded-xl px-5 py-3 text-sm font-semibold text-white"
                            style={{ background: config.accentColor }}
                          >
                            {getContent(section, "buttonText")}
                            <span className="ml-2">→</span>
                          </span>
                        )}

                        {section.type === "gallery" && (
                          <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-3">
                            {[1, 2, 3].map((number) => (
                              <div key={number} className="flex aspect-[4/3] items-center justify-center rounded-xl bg-gray-100 text-xs text-gray-400">
                                Project {number}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="absolute bottom-2 left-3 rounded-md bg-white/90 px-2 py-1 text-[9px] font-medium uppercase tracking-wider text-gray-500 opacity-0 shadow-sm transition group-hover:opacity-100">
                        {index + 1} · {definition?.name || section.type}
                      </div>
                    </section>
                  );
                })
              )}
            </div>
            <p className="mt-3 text-center text-[10px] text-gray-400">
              {device === "desktop" ? "Desktop canvas" : device === "tablet" ? "Tablet canvas" : "Mobile canvas"} · Select any section to edit it
            </p>
          </div>
        </section>

        <aside className="hidden min-h-0 overflow-y-auto border-l border-gray-200 bg-white lg:block">
          {selectedSection ? (
            <>
              <div className="flex items-center justify-between border-b border-gray-100 px-5 py-4">
                <div>
                  <h2 className="text-sm font-bold">{SECTION_LIBRARY.find((item) => item.type === selectedSection.type)?.name || selectedSection.type} section</h2>
                  <p className="mt-1 text-[10px] text-gray-500">Section properties</p>
                </div>
                <button onClick={() => deleteSection(selectedSection.id)} title="Delete section" className="rounded-lg p-2 text-gray-400 hover:bg-red-50 hover:text-red-600">⌫</button>
              </div>

              <div className="flex border-b border-gray-100 px-4">
                {["content", "style"].map((tab) => (
                  <button key={tab} onClick={() => setInspectorTab(tab)} className={`flex-1 border-b-2 py-3 text-xs font-semibold capitalize ${inspectorTab === tab ? "border-violet-600 text-violet-700" : "border-transparent text-gray-500"}`}>
                    {tab}
                  </button>
                ))}
              </div>

              <div className="space-y-5 p-5">
                {inspectorTab === "content" ? (
                  <>
                    {Object.entries(selectedSection.content || {}).map(([key, value]) => {
                      if (typeof value !== "string") return null;
                      const label = key.replace(/([A-Z])/g, " $1").replace(/^./, (character) => character.toUpperCase());

                      return (
                        <label key={key} className="block">
                          <span className="mb-2 block text-xs font-semibold text-gray-700">{label}</span>
                          {key === "description" ? (
                            <textarea
                              value={value}
                              rows={4}
                              onChange={(event) => updateContent(key, event.target.value)}
                              className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-xs leading-5 outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
                            />
                          ) : (
                            <input
                              value={value}
                              onChange={(event) => updateContent(key, event.target.value)}
                              className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-xs outline-none focus:border-violet-400 focus:ring-2 focus:ring-violet-100"
                            />
                          )}
                        </label>
                      );
                    })}
                    <div className="rounded-xl bg-amber-50 p-3 text-[11px] leading-5 text-amber-800">
                      Edits are currently local to this session. Database saving will be connected next.
                    </div>
                  </>
                ) : (
                  <>
                    <label className="block">
                      <span className="mb-2 block text-xs font-semibold text-gray-700">Text alignment</span>
                      <div className="grid grid-cols-3 gap-2">
                        {["left", "center", "right"].map((alignment) => (
                          <button key={alignment} onClick={() => updateConfig("alignment", alignment)} className={`rounded-lg border px-2 py-2 text-xs capitalize ${selectedSection.config?.alignment === alignment ? "border-violet-400 bg-violet-50 text-violet-700" : "border-gray-200 text-gray-600"}`}>
                            {alignment}
                          </button>
                        ))}
                      </div>
                    </label>

                    {[
                      ["background", "Background"],
                      ["textColor", "Text color"],
                      ["accentColor", "Accent color"],
                    ].map(([key, label]) => (
                      <label key={key} className="flex items-center justify-between gap-3">
                        <span className="text-xs font-medium text-gray-700">{label}</span>
                        <input type="color" value={selectedSection.config?.[key] || INITIAL_CONFIG[key]} onChange={(event) => updateConfig(key, event.target.value)} className="h-9 w-12 cursor-pointer rounded-lg border border-gray-200 bg-white p-1" />
                      </label>
                    ))}

                    <label className="block">
                      <span className="mb-2 flex justify-between text-xs font-semibold text-gray-700">
                        Section padding <span>{selectedSection.config?.padding ?? 64}px</span>
                      </span>
                      <input type="range" min="24" max="120" step="4" value={selectedSection.config?.padding ?? 64} onChange={(event) => updateConfig("padding", Number(event.target.value))} className="w-full accent-violet-600" />
                    </label>

                    <label className="block">
                      <span className="mb-2 flex justify-between text-xs font-semibold text-gray-700">
                        Border radius <span>{selectedSection.config?.radius ?? 16}px</span>
                      </span>
                      <input type="range" min="0" max="40" step="2" value={selectedSection.config?.radius ?? 16} onChange={(event) => updateConfig("radius", Number(event.target.value))} className="w-full accent-violet-600" />
                    </label>
                  </>
                )}
              </div>
            </>
          ) : (
            <div className="p-6">
              <h2 className="text-sm font-bold">Template settings</h2>
              <p className="mt-2 text-xs leading-5 text-gray-500">Select a section on the canvas to edit its content and styling.</p>
              <div className="mt-6 space-y-4 border-t border-gray-100 pt-5">
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Template</p>
                  <p className="mt-1 text-sm font-medium">{template.name}</p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Category</p>
                  <p className="mt-1 text-sm">{template.websiteCategory?.name || template.category || "General"}</p>
                </div>
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-gray-400">Pages</p>
                  <p className="mt-1 text-sm">{template.pages?.length || 0}</p>
                </div>
              </div>
            </div>
          )}
        </aside>
      </div>

      <footer className="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3">
        <p className="text-[11px] text-gray-500">
          {dirty ? "Unsaved local changes" : "All loaded content unchanged"} · {template.name}
        </p>
        <button
          onClick={() => router.push("/admin/templates")}
          className="rounded-lg border border-gray-200 px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50"
        >
          Exit editor
        </button>
      </footer>
    </main>
  );
}
