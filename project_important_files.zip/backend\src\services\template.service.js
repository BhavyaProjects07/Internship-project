
const prisma = require("../lib/prisma");

const templateInclude = {
  websiteCategory: true,
  pages: {
    orderBy: { order: "asc" },
    include: {
      sections: {
        orderBy: { order: "asc" },
      },
    },
  },
};

const getAllTemplates = async ({ includeDrafts = false } = {}) => {
  return prisma.template.findMany({
    where: includeDrafts ? {} : { status: "PUBLISHED" },
    orderBy: { updatedAt: "desc" },
    include: { websiteCategory: true },
  });
};

const getTemplateById = async (id, { includeDrafts = false } = {}) => {
  return prisma.template.findFirst({
    where: {
      id,
      ...(includeDrafts ? {} : { status: "PUBLISHED" }),
    },
    include: templateInclude,
  });
};

const createTemplate = async ({
  name,
  description,
  categoryId,
  thumbnail,
}) => {
  if (typeof name !== "string" || !name.trim()) {
    const error = new Error("Template name is required");
    error.statusCode = 400;
    throw error;
  }

  let categoryName = "General";

  if (categoryId) {
    const category = await prisma.websiteCategory.findUnique({
      where: { id: categoryId },
      select: { id: true, name: true },
    });

    if (!category) {
      const error = new Error("Category not found");
      error.statusCode = 404;
      throw error;
    }

    categoryName = category.name;
  }

  const slugBase =
    name
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "template";

  return prisma.template.create({
    data: {
      name: name.trim(),
      slug: `${slugBase}-${Date.now().toString(36)}`,
      description: description?.trim() || null,
      category: categoryName,
      categoryId: categoryId || null,
      thumbnail: thumbnail?.trim() || null,
      status: "DRAFT",
      pages: {
        create: {
          name: "Home",
          slug: "home",
          order: 0,
        },
      },
    },
    include: templateInclude,
  });
};

const updateTemplate = async (
  id,
  { name, description, categoryId, thumbnail }
) => {
  const data = {};

  if (name !== undefined) {
    if (typeof name !== "string" || !name.trim()) {
      const error = new Error("Template name is required");
      error.statusCode = 400;
      throw error;
    }
    data.name = name.trim();
  }

  if (description !== undefined) {
    data.description = description?.trim() || null;
  }

  if (thumbnail !== undefined) {
    data.thumbnail = thumbnail?.trim() || null;
  }

  if (categoryId !== undefined) {
    if (!categoryId) {
      data.categoryId = null;
      data.category = "General";
    } else {
      const category = await prisma.websiteCategory.findUnique({
        where: { id: categoryId },
        select: { id: true, name: true },
      });

      if (!category) {
        const error = new Error("Category not found");
        error.statusCode = 404;
        throw error;
      }

      data.categoryId = category.id;
      data.category = category.name;
    }
  }

  return prisma.template.update({
    where: { id },
    data,
    include: templateInclude,
  });
};

const assignTemplateCategory = async (templateId, categoryId) => {
  return updateTemplate(templateId, { categoryId });
};

const setTemplateStatus = async (id, status) => {
  if (!["DRAFT", "PUBLISHED"].includes(status)) {
    const error = new Error("Status must be DRAFT or PUBLISHED");
    error.statusCode = 400;
    throw error;
  }

  const template = await prisma.template.findUnique({
    where: { id },
    include: { pages: true },
  });

  if (!template) {
    const error = new Error("Template not found");
    error.statusCode = 404;
    throw error;
  }

  if (status === "PUBLISHED" && template.pages.length === 0) {
    const error = new Error("Add at least one page before publishing");
    error.statusCode = 400;
    throw error;
  }

  return prisma.template.update({
    where: { id },
    data: {
      status,
      publishedAt: status === "PUBLISHED" ? new Date() : null,
    },
    include: templateInclude,
  });
};

const deleteTemplate = async (id) => {
  return prisma.template.delete({
    where: { id },
  });
};




const createSection = async (templateId, pageId, { type, content, config }) => {
  if (typeof type !== "string" || !type.trim()) {
    const error = new Error("Section type is required");
    error.statusCode = 400;
    throw error;
  }

  const page = await prisma.templatePage.findFirst({
    where: { id: pageId, templateId },
    select: { id: true },
  });

  if (!page) {
    const error = new Error("Page not found in this template");
    error.statusCode = 404;
    throw error;
  }

  const lastSection = await prisma.templateSection.findFirst({
    where: { pageId },
    orderBy: { order: "desc" },
    select: { order: true },
  });

  return prisma.templateSection.create({
    data: {
      type: type.trim(),
      order: (lastSection?.order ?? -1) + 1,
      content: content ?? {},
      config: config ?? undefined,
      pageId,
    },
  });
};

const updateSection = async (sectionId, { type, content, config }) => {
  const existing = await prisma.templateSection.findUnique({
    where: { id: sectionId },
    select: { id: true },
  });

  if (!existing) {
    const error = new Error("Section not found");
    error.statusCode = 404;
    throw error;
  }

  const data = {};

  if (type !== undefined) {
    if (typeof type !== "string" || !type.trim()) {
      const error = new Error("Section type must be a non-empty string");
      error.statusCode = 400;
      throw error;
    }
    data.type = type.trim();
  }

  if (content !== undefined) data.content = content;
  if (config !== undefined) data.config = config;

  return prisma.templateSection.update({
    where: { id: sectionId },
    data,
  });
};

const deleteSection = async (sectionId) => {
  return prisma.templateSection.delete({
    where: { id: sectionId },
  });
};

const reorderSections = async (templateId, pageId, sectionIds) => {
  if (
    !Array.isArray(sectionIds) ||
    sectionIds.some((id) => typeof id !== "string" || !id) ||
    new Set(sectionIds).size !== sectionIds.length
  ) {
    const error = new Error(
      "sectionIds must be an array of unique section IDs"
    );
    error.statusCode = 400;
    throw error;
  }

  const page = await prisma.templatePage.findFirst({
    where: { id: pageId, templateId },
    select: { id: true },
  });

  if (!page) {
    const error = new Error("Page not found in this template");
    error.statusCode = 404;
    throw error;
  }

  const currentSections = await prisma.templateSection.findMany({
    where: { pageId },
    select: { id: true },
  });

  const currentIds = new Set(currentSections.map((section) => section.id));

  // Require the complete list so a partial reorder cannot lose sections.
  if (
    currentIds.size !== sectionIds.length ||
    sectionIds.some((id) => !currentIds.has(id))
  ) {
    const error = new Error(
      "sectionIds must contain every section on this page exactly once"
    );
    error.statusCode = 400;
    throw error;
  }

  await prisma.$transaction(
    sectionIds.map((id, index) =>
      prisma.templateSection.update({
        where: { id },
        data: { order: index },
      })
    )
  );

  return prisma.templateSection.findMany({
    where: { pageId },
    orderBy: { order: "asc" },
  });
};



const MAX_EDITOR_DOCUMENT_BYTES = 1_000_000;

const validateEditorDocument = (document) => {
  if (
    !document ||
    typeof document !== "object" ||
    Array.isArray(document) ||
    !Array.isArray(document.content) ||
    !document.root ||
    typeof document.root !== "object" ||
    Array.isArray(document.root)
  ) {
    const error = new Error("Invalid Puck editor document");
    error.statusCode = 400;
    throw error;
  }

  let serialized;

  try {
    serialized = JSON.stringify(document);
  } catch {
    const error = new Error("Editor document must be valid JSON");
    error.statusCode = 400;
    throw error;
  }

  if (Buffer.byteLength(serialized, "utf8") > MAX_EDITOR_DOCUMENT_BYTES) {
    const error = new Error("Editor document exceeds the 1 MB limit");
    error.statusCode = 413;
    throw error;
  }

  return document;
};

const getPageEditorData = async (templateId, pageId) => {
  const page = await prisma.templatePage.findFirst({
    where: {
      id: pageId,
      templateId,
    },
    select: {
      id: true,
      name: true,
      slug: true,
      order: true,
      editorData: true,
      sections: {
        orderBy: { order: "asc" },
      },
    },
  });

  if (!page) {
    const error = new Error("Page not found in this template");
    error.statusCode = 404;
    throw error;
  }

  return page;
};

const savePageEditorData = async (templateId, pageId, document) => {
  validateEditorDocument(document);

  const page = await prisma.templatePage.findFirst({
    where: {
      id: pageId,
      templateId,
    },
    select: { id: true },
  });

  if (!page) {
    const error = new Error("Page not found in this template");
    error.statusCode = 404;
    throw error;
  }

  return prisma.templatePage.update({
    where: { id: pageId },
    data: {
      editorData: document,
    },
    select: {
      id: true,
      name: true,
      slug: true,
      editorData: true,
      updatedAt: true,
    },
  });
};




module.exports = {
  getAllTemplates,
  getTemplateById,
  createTemplate,
  updateTemplate,
  assignTemplateCategory,
  setTemplateStatus,
  deleteTemplate,
  createSection,
  updateSection,
  deleteSection,
  reorderSections,
  getPageEditorData,
  savePageEditorData,

};