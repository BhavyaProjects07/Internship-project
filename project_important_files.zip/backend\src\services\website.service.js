
const prisma = require("../lib/prisma");

const templateInclude = {
  websiteCategory: true,
  pages: {
    orderBy: { order: "asc" },
    include: {
      sections: { orderBy: { order: "asc" } },
    },
  },
};

const slugify = (value) =>
  value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 70) || "template";

const getAllTemplates = async ({ includeDrafts = false } = {}) => {
  return prisma.template.findMany({
    where: includeDrafts ? {} : { status: "PUBLISHED" },
    orderBy: { updatedAt: "desc" },
    include: { websiteCategory: true },
  });
};

const getTemplateById = async (id, { includeDrafts = false } = {}) => {
  return prisma.template.findFirst({
    where: {
      id,
      ...(includeDrafts ? {} : { status: "PUBLISHED" }),
    },
    include: templateInclude,
  });
};

const createTemplate = async ({
  name,
  description,
  categoryId,
  thumbnail,
}) => {
  const cleanName = name.trim();
  const baseSlug = slugify(cleanName);
  const slug = `${baseSlug}-${Date.now().toString(36)}`;

  let category = "General";

  if (categoryId) {
    const categoryRecord = await prisma.websiteCategory.findUnique({
      where: { id: categoryId },
      select: { id: true, name: true },
    });

    if (!categoryRecord) {
      const error = new Error("Category not found");
      error.statusCode = 404;
      throw error;
    }

    category = categoryRecord.name;
  }

  return prisma.template.create({
    data: {
      name: cleanName,
      slug,
      description: description?.trim() || null,
      category,
      categoryId: categoryId || null,
      thumbnail: thumbnail?.trim() || null,
      status: "DRAFT",
      pages: {
        create: {
          name: "Home",
          slug: "home",
          order: 0,
        },
      },
    },
    include: templateInclude,
  });
};

const updateTemplate = async (
  id,
  { name, description, categoryId, thumbnail }
) => {
  const existing = await prisma.template.findUnique({
    where: { id },
    select: { id: true },
  });

  if (!existing) {
    const error = new Error("Template not found");
    error.statusCode = 404;
    throw error;
  }

  const data = {};

  if (name !== undefined) {
    if (typeof name !== "string" || !name.trim()) {
      const error = new Error("Template name is required");
      error.statusCode = 400;
      throw error;
    }

    data.name = name.trim();
  }

  if (description !== undefined) {
    data.description = description?.trim() || null;
  }

  if (thumbnail !== undefined) {
    data.thumbnail = thumbnail?.trim() || null;
  }

  if (categoryId !== undefined) {
    if (categoryId === null || categoryId === "") {
      data.categoryId = null;
    } else {
      const categoryRecord = await prisma.websiteCategory.findUnique({
        where: { id: categoryId },
        select: { id: true, name: true },
      });

      if (!categoryRecord) {
        const error = new Error("Category not found");
        error.statusCode = 404;
        throw error;
      }

      data.categoryId = categoryRecord.id;
      data.category = categoryRecord.name;
    }
  }

  return prisma.template.update({
    where: { id },
    data,
    include: templateInclude,
  });
};

const assignTemplateCategory = async (templateId, categoryId) => {
  return updateTemplate(templateId, { categoryId });
};

const setTemplateStatus = async (id, status) => {
  if (!["DRAFT", "PUBLISHED"].includes(status)) {
    const error = new Error("Status must be DRAFT or PUBLISHED");
    error.statusCode = 400;
    throw error;
  }

  const template = await prisma.template.findUnique({
    where: { id },
    include: { pages: true },
  });

  if (!template) {
    const error = new Error("Template not found");
    error.statusCode = 404;
    throw error;
  }

  if (status === "PUBLISHED" && template.pages.length === 0) {
    const error = new Error(
      "Add at least one page before publishing this template"
    );
    error.statusCode = 400;
    throw error;
  }

  return prisma.template.update({
    where: { id },
    data: {
      status,
      publishedAt: status === "PUBLISHED" ? new Date() : null,
    },
    include: templateInclude,
  });
};

const deleteTemplate = async (id) => {
  const existing = await prisma.template.findUnique({
    where: { id },
    select: { id: true },
  });

  if (!existing) {
    const error = new Error("Template not found");
    error.statusCode = 404;
    throw error;
  }

  return prisma.template.delete({ where: { id } });
};

module.exports = {
  getAllTemplates,
  getTemplateById,
  createTemplate,
  updateTemplate,
  assignTemplateCategory,
  setTemplateStatus,
  deleteTemplate,
};
