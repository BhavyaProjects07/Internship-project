"use client";

import { useCallback, useEffect, useState } from "react";
import { useAuth } from "@clerk/nextjs";
import { useParams, useRouter } from "next/navigation";
import PuckEditorClient from "@/components/website-builder/PuckEditorClient";

const API_URL = (
  process.env.NEXT_PUBLIC_API_URL || "http://localhost:5000/api"
).replace(/\/+$/, "");

export default function PuckTestPage() {
  const { id } = useParams();
  const router = useRouter();
  const { isLoaded, isSignedIn, getToken } = useAuth();

  const [template, setTemplate] = useState(null);
  const [pageId, setPageId] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  const loadTemplate = useCallback(async () => {
    if (!id) return;

    setLoading(true);
    setError("");

    try {
      const token = await getToken();

      if (!token) {
        throw new Error("Your session has expired. Please sign in again.");
      }

      const response = await fetch(
        `${API_URL}/templates/admin/${encodeURIComponent(id)}`,
        {
          headers: { Authorization: `Bearer ${token}` },
          cache: "no-store",
        }
      );

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || "Unable to load template.");
      }

      const loaded = result.data;
      const pages = [...(loaded.pages || [])].sort(
        (a, b) => a.order - b.order
      );

      if (!pages.length) {
        throw new Error("This template has no pages yet.");
      }

      setTemplate(loaded);
      setPageId((current) =>
        pages.some((page) => page.id === current)
          ? current
          : pages[0].id
      );
    } catch (err) {
      setError(err.message || "Unable to load template.");
    } finally {
      setLoading(false);
    }
  }, [id, getToken]);

  useEffect(() => {
    if (!isLoaded) return;

    if (!isSignedIn) {
      setError("Please sign in to edit templates.");
      setLoading(false);
      return;
    }

    loadTemplate();
  }, [isLoaded, isSignedIn, loadTemplate]);

  if (loading) {
    return <main className="p-8">Loading template…</main>;
  }

  if (error) {
    return (
      <main className="space-y-4 p-8">
        <p role="alert" className="text-red-600">{error}</p>
        <button
          className="rounded border px-4 py-2"
          onClick={() => router.push(`/admin/templates/${id}/editor`)}
        >
          Return to existing editor
        </button>
      </main>
    );
  }

  const activePage = template.pages.find((page) => page.id === pageId);

  return (
    <main className="min-h-screen bg-gray-50">
      <header className="flex flex-wrap items-center justify-between gap-4 border-b bg-white px-5 py-4">
        <div>
          <h1 className="font-semibold">{template.name}</h1>
          <p className="text-sm text-gray-500">
            Puck editor · {activePage?.name || "Select a page"}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <label className="text-sm">
            Page{" "}
            <select
              value={pageId}
              onChange={(event) => setPageId(event.target.value)}
              className="ml-2 rounded border bg-white px-3 py-2"
            >
              {template.pages
                .slice()
                .sort((a, b) => a.order - b.order)
                .map((page) => (
                  <option key={page.id} value={page.id}>
                    {page.name}
                  </option>
                ))}
            </select>
          </label>

          <button
            className="rounded border px-3 py-2 text-sm"
            onClick={() => router.push(`/admin/templates/${id}/editor`)}
          >
            Old editor
          </button>
        </div>
      </header>

      {pageId && (
        <PuckEditorClient
          key={pageId}
          templateId={id}
          pageId={pageId}
          getToken={getToken}
        />
      )}
    </main>
  );
}
