
import React from "react";

/*
 * Website Builder component configuration.
 *
 * Design goals:
 * - Reusable components rather than template-specific pages.
 * - Structured, serializable content and styling.
 * - Consistent styling controls across components.
 * - Nested layouts using Puck drop zones.
 * - A component library that can grow without duplicating render logic.
 */

const ALIGNMENT_OPTIONS = [
  { label: "Left", value: "left" },
  { label: "Center", value: "center" },
  { label: "Right", value: "right" },
  { label: "Justify", value: "justify" },
];

const COLOR_SCHEME_OPTIONS = [
  { label: "Light", value: "light" },
  { label: "Dark", value: "dark" },
  { label: "Transparent", value: "transparent" },
];

const WIDTH_OPTIONS = [
  { label: "Auto", value: "auto" },
  { label: "25%", value: "25%" },
  { label: "50%", value: "50%" },
  { label: "75%", value: "75%" },
  { label: "100%", value: "100%" },
];

const FONT_WEIGHT_OPTIONS = [
  { label: "Normal (400)", value: "400" },
  { label: "Medium (500)", value: "500" },
  { label: "Semibold (600)", value: "600" },
  { label: "Bold (700)", value: "700" },
  { label: "Extra bold (800)", value: "800" },
];

const FONT_STYLE_OPTIONS = [
  { label: "Normal", value: "normal" },
  { label: "Italic", value: "italic" },
];

const TEXT_DECORATION_OPTIONS = [
  { label: "None", value: "none" },
  { label: "Underline", value: "underline" },
  { label: "Line through", value: "line-through" },
];

const DISPLAY_OPTIONS = [
  { label: "Block", value: "block" },
  { label: "Flex", value: "flex" },
  { label: "Grid", value: "grid" },
];

const FLEX_DIRECTION_OPTIONS = [
  { label: "Row", value: "row" },
  { label: "Column", value: "column" },
  { label: "Row reverse", value: "row-reverse" },
  { label: "Column reverse", value: "column-reverse" },
];

const JUSTIFY_OPTIONS = [
  { label: "Start", value: "flex-start" },
  { label: "Center", value: "center" },
  { label: "End", value: "flex-end" },
  { label: "Space between", value: "space-between" },
  { label: "Space around", value: "space-around" },
  { label: "Space evenly", value: "space-evenly" },
];

const ALIGN_ITEMS_OPTIONS = [
  { label: "Start", value: "flex-start" },
  { label: "Center", value: "center" },
  { label: "End", value: "flex-end" },
  { label: "Stretch", value: "stretch" },
];

const BORDER_STYLE_OPTIONS = [
  { label: "None", value: "none" },
  { label: "Solid", value: "solid" },
  { label: "Dashed", value: "dashed" },
  { label: "Dotted", value: "dotted" },
];

const OBJECT_FIT_OPTIONS = [
  { label: "Cover", value: "cover" },
  { label: "Contain", value: "contain" },
  { label: "Fill", value: "fill" },
];

const BACKGROUND_SIZE_OPTIONS = [
  { label: "Cover", value: "cover" },
  { label: "Contain", value: "contain" },
  { label: "Auto", value: "auto" },
];

const BACKGROUND_POSITION_OPTIONS = [
  { label: "Center", value: "center" },
  { label: "Top", value: "top" },
  { label: "Bottom", value: "bottom" },
  { label: "Left", value: "left" },
  { label: "Right", value: "right" },
];

const SPACING_OPTIONS = [
  { label: "0", value: "0px" },
  { label: "4px", value: "4px" },
  { label: "8px", value: "8px" },
  { label: "12px", value: "12px" },
  { label: "16px", value: "16px" },
  { label: "24px", value: "24px" },
  { label: "32px", value: "32px" },
  { label: "48px", value: "48px" },
  { label: "64px", value: "64px" },
  { label: "96px", value: "96px" },
];

const selectField = (label, options) => ({
  type: "select",
  label,
  options,
});

const numberField = (label, min = 0, max = 200) => ({
  type: "number",
  label,
  min,
  max,
});

const textField = (label) => ({
  type: "text",
  label,
});

const textareaField = (label) => ({
  type: "textarea",
  label,
});

/*
 * Shared design controls.
 *
 * All dimensions are stored as strings where CSS units are useful.
 * This keeps the saved page structure flexible and serializable.
 */
const typographyFields = {
  fontFamily: selectField("Font family", [
    { label: "Inherit", value: "inherit" },
    { label: "Arial", value: "Arial, sans-serif" },
    { label: "Inter", value: "Inter, sans-serif" },
    { label: "Georgia", value: "Georgia, serif" },
    { label: "Times New Roman", value: '"Times New Roman", serif' },
    { label: "Monospace", value: "monospace" },
  ]),
  fontSize: numberField("Font size (px)", 8, 160),
  fontWeight: selectField("Font weight", FONT_WEIGHT_OPTIONS),
  fontStyle: selectField("Font style", FONT_STYLE_OPTIONS),
  textDecoration: selectField(
    "Text decoration",
    TEXT_DECORATION_OPTIONS
  ),
  lineHeight: numberField("Line height", 0.5, 4),
  letterSpacing: numberField("Letter spacing (px)", -10, 30),
  color: textField("Text color"),
  textAlign: selectField("Text alignment", ALIGNMENT_OPTIONS),
};

const spacingFields = {
  marginTop: selectField("Margin top", SPACING_OPTIONS),
  marginRight: selectField("Margin right", SPACING_OPTIONS),
  marginBottom: selectField("Margin bottom", SPACING_OPTIONS),
  marginLeft: selectField("Margin left", SPACING_OPTIONS),
  paddingTop: selectField("Padding top", SPACING_OPTIONS),
  paddingRight: selectField("Padding right", SPACING_OPTIONS),
  paddingBottom: selectField("Padding bottom", SPACING_OPTIONS),
  paddingLeft: selectField("Padding left", SPACING_OPTIONS),
};

const boxStyleFields = {
  backgroundColor: textField("Background color"),
  backgroundImage: textField("Background image URL"),
  backgroundSize: selectField(
    "Background image size",
    BACKGROUND_SIZE_OPTIONS
  ),
  backgroundPosition: selectField(
    "Background image position",
    BACKGROUND_POSITION_OPTIONS
  ),
  width: selectField("Width", WIDTH_OPTIONS),
  maxWidth: numberField("Maximum width (px)", 0, 3000),
  minHeight: numberField("Minimum height (px)", 0, 2000),
  borderStyle: selectField("Border style", BORDER_STYLE_OPTIONS),
  borderColor: textField("Border color"),
  borderWidth: numberField("Border width (px)", 0, 30),
  borderRadius: numberField("Corner radius (px)", 0, 200),
  boxShadow: textField(
    "Box shadow (CSS)"
  ),
};

const spacingDefaults = {
  marginTop: "0px",
  marginRight: "0px",
  marginBottom: "16px",
  marginLeft: "0px",
  paddingTop: "0px",
  paddingRight: "0px",
  paddingBottom: "0px",
  paddingLeft: "0px",
};

const boxStyleDefaults = {
  backgroundColor: "transparent",
  backgroundImage: "",
  backgroundSize: "cover",
  backgroundPosition: "center",
  width: "100%",
  maxWidth: 0,
  minHeight: 0,
  borderStyle: "none",
  borderColor: "#e5e7eb",
  borderWidth: 0,
  borderRadius: 0,
  boxShadow: "",
};

function buildBoxStyle(props = {}) {
  const {
    backgroundColor = "transparent",
    backgroundImage = "",
    backgroundSize = "cover",
    backgroundPosition = "center",
    width = "100%",
    maxWidth = 0,
    minHeight = 0,
    borderStyle = "none",
    borderColor = "#e5e7eb",
    borderWidth = 0,
    borderRadius = 0,
    boxShadow = "",
    marginTop = "0px",
    marginRight = "0px",
    marginBottom = "16px",
    marginLeft = "0px",
    paddingTop = "0px",
    paddingRight = "0px",
    paddingBottom = "0px",
    paddingLeft = "0px",
  } = props;

  return {
    boxSizing: "border-box",
    width,
    maxWidth: maxWidth > 0 ? `${maxWidth}px` : undefined,
    minHeight: minHeight > 0 ? `${minHeight}px` : undefined,
    marginTop,
    marginRight,
    marginBottom,
    marginLeft,
    paddingTop,
    paddingRight,
    paddingBottom,
    paddingLeft,
    backgroundColor,
    backgroundImage: backgroundImage
      ? `url("${backgroundImage.replace(/["\\\n\r]/g, "")}")`
      : undefined,
    backgroundSize,
    backgroundPosition,
    backgroundRepeat: "no-repeat",
    borderStyle,
    borderColor,
    borderWidth: `${borderWidth}px`,
    borderRadius: `${borderRadius}px`,
    boxShadow: boxShadow || undefined,
  };
}

function buildTypographyStyle(props = {}) {
  const {
    fontFamily = "inherit",
    fontSize = 16,
    fontWeight = "400",
    fontStyle = "normal",
    textDecoration = "none",
    lineHeight = 1.6,
    letterSpacing = 0,
    color = "#171717",
    textAlign = "left",
  } = props;

  return {
    fontFamily,
    fontSize: `${fontSize}px`,
    fontWeight,
    fontStyle,
    textDecoration,
    lineHeight,
    letterSpacing: `${letterSpacing}px`,
    color,
    textAlign,
  };
}

function buildElementStyle(props = {}) {
  return {
    ...buildBoxStyle(props),
    ...buildTypographyStyle(props),
  };
}

const commonDesignDefaults = {
  ...spacingDefaults,
  ...boxStyleDefaults,
};

const typographyDefaults = {
  fontFamily: "inherit",
  fontSize: 16,
  fontWeight: "400",
  fontStyle: "normal",
  textDecoration: "none",
  lineHeight: 1.6,
  letterSpacing: 0,
  color: "#171717",
  textAlign: "left",
};

/*
 * All available building blocks are registered here.
 *
 * Nested components use Puck's renderDropZone API so that
 * containers and layouts can hold other components.
 */
const puckConfig = {
  root: {
    fields: {
      title: textField("Page title"),
      backgroundColor: textField("Page background"),
      contentWidth: selectField("Content width", [
        { label: "Narrow", value: "760px" },
        { label: "Standard", value: "1100px" },
        { label: "Wide", value: "1320px" },
        { label: "Full width", value: "100%" },
      ]),
    },
    defaultProps: {
      title: "Untitled page",
      backgroundColor: "#ffffff",
      contentWidth: "100%",
    },
    render: ({ children, backgroundColor }) => (
      <main
        style={{
          minHeight: "100%",
          backgroundColor: backgroundColor || "#ffffff",
        }}
      >
        {children}
      </main>
    ),
  },

  categories: {
    layout: {
      title: "Layout",
      components: ["Container", "Columns", "Spacer", "Divider"],
      defaultExpanded: true,
    },
    typography: {
      title: "Typography",
      components: ["Heading", "Text", "RichText", "Label"],
      defaultExpanded: true,
    },
    media: {
      title: "Media",
      components: ["Image"],
      defaultExpanded: true,
    },
    actions: {
      title: "Actions",
      components: ["Button", "Link"],
      defaultExpanded: true,
    },
    content: {
      title: "Content",
      components: ["List", "Badge", "Card"],
      defaultExpanded: true,
    },
  },

  components: {
    Heading: {
      label: "Heading",
      fields: {
        text: textField("Heading text"),
        level: selectField("Heading level", [
          { label: "H1", value: "h1" },
          { label: "H2", value: "h2" },
          { label: "H3", value: "h3" },
          { label: "H4", value: "h4" },
          { label: "H5", value: "h5" },
          { label: "H6", value: "h6" },
        ]),
        ...typographyFields,
        ...spacingFields,
        ...boxStyleFields,
      },
      defaultProps: {
        text: "Your heading goes here",
        level: "h2",
        ...typographyDefaults,
        fontSize: 36,
        fontWeight: "700",
        lineHeight: 1.2,
        ...commonDesignDefaults,
        marginBottom: "16px",
      },
      render: ({ text, level, ...props }) => {
        const allowedLevels = ["h1", "h2", "h3", "h4", "h5", "h6"];
        const Tag = allowedLevels.includes(level) ? level : "h2";

        return (
          <Tag style={buildElementStyle(props)}>
            {text}
          </Tag>
        );
      },
    },

    Text: {
      label: "Paragraph",
      fields: {
        text: textareaField("Paragraph text"),
        ...typographyFields,
        ...spacingFields,
        ...boxStyleFields,
      },
      defaultProps: {
        text: "Write your paragraph here. Select this element to customize its content and appearance.",
        ...typographyDefaults,
        fontSize: 16,
        color: "#525252",
        lineHeight: 1.8,
        ...commonDesignDefaults,
      },
      render: ({ text, ...props }) => (
        <p style={buildElementStyle(props)}>
          {text}
        </p>
      ),
    },

    RichText: {
      label: "Rich text",
      fields: {
        text: textareaField("Text content"),
        ...typographyFields,
        ...spacingFields,
        ...boxStyleFields,
      },
      defaultProps: {
        text: "Add a longer text block here.",
        ...typographyDefaults,
        fontSize: 16,
        color: "#404040",
        lineHeight: 1.8,
        ...commonDesignDefaults,
      },
      render: ({ text, ...props }) => (
        <div style={buildElementStyle(props)}>
          {text}
        </div>
      ),
    },

    Label: {
      label: "Small label",
      fields: {
        text: textField("Label text"),
        ...typographyFields,
        ...spacingFields,
        ...boxStyleFields,
      },
      defaultProps: {
        text: "INTRODUCTION",
        ...typographyDefaults,
        fontSize: 12,
        fontWeight: "700",
        letterSpacing: 1.5,
        color: "#6741ff",
        ...commonDesignDefaults,
      },
      render: ({ text, ...props }) => (
        <span
          style={{
            ...buildElementStyle(props),
            display: "inline-block",
          }}
        >
          {text}
        </span>
      ),
    },

    Button: {
      label: "Button",
      fields: {
        label: textField("Button label"),
        href: textField("Destination URL"),
        target: selectField("Open link in", [
          { label: "Same tab", value: "_self" },
          { label: "New tab", value: "_blank" },
        ]),
        backgroundColor: textField("Background color"),
        color: textField("Text color"),
        fontSize: numberField("Font size (px)", 8, 48),
        fontWeight: selectField("Font weight", FONT_WEIGHT_OPTIONS),
        paddingY: numberField("Vertical padding (px)", 0, 80),
        paddingX: numberField("Horizontal padding (px)", 0, 120),
        borderRadius: numberField("Corner radius (px)", 0, 100),
        borderStyle: selectField("Border style", BORDER_STYLE_OPTIONS),
        borderColor: textField("Border color"),
        borderWidth: numberField("Border width (px)", 0, 20),
        width: selectField("Width", WIDTH_OPTIONS),
        align: selectField("Alignment", ALIGNMENT_OPTIONS),
        marginTop: selectField("Margin top", SPACING_OPTIONS),
        marginBottom: selectField("Margin bottom", SPACING_OPTIONS),
      },
      defaultProps: {
        label: "Get started",
        href: "#contact",
        target: "_self",
        backgroundColor: "#6741ff",
        color: "#ffffff",
        fontSize: 16,
        fontWeight: "600",
        paddingY: 12,
        paddingX: 24,
        borderRadius: 8,
        borderStyle: "none",
        borderColor: "#6741ff",
        borderWidth: 0,
        width: "auto",
        align: "left",
        marginTop: "0px",
        marginBottom: "16px",
      },
      render: ({
        label,
        href,
        target,
        backgroundColor,
        color,
        fontSize,
        fontWeight,
        paddingY,
        paddingX,
        borderRadius,
        borderStyle,
        borderColor,
        borderWidth,
        width,
        align,
        marginTop,
        marginBottom,
      }) => (
        <div
          style={{
            width: "100%",
            textAlign: align,
            marginTop,
            marginBottom,
          }}
        >
          <a
            href={href || "#"}
            target={target}
            rel={target === "_blank" ? "noopener noreferrer" : undefined}
            style={{
              display: width === "100%" ? "flex" : "inline-flex",
              width,
              boxSizing: "border-box",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor,
              color,
              fontSize: `${fontSize}px`,
              fontWeight,
              padding: `${paddingY}px ${paddingX}px`,
              borderRadius: `${borderRadius}px`,
              border: `${borderWidth}px ${borderStyle} ${borderColor}`,
              textDecoration: "none",
              cursor: "pointer",
            }}
          >
            {label}
          </a>
        </div>
      ),
    },

    Link: {
      label: "Text link",
      fields: {
        text: textField("Link text"),
        href: textField("Destination URL"),
        target: selectField("Open link in", [
          { label: "Same tab", value: "_self" },
          { label: "New tab", value: "_blank" },
        ]),
        ...typographyFields,
        ...spacingFields,
      },
      defaultProps: {
        text: "Learn more",
        href: "#",
        target: "_self",
        ...typographyDefaults,
        color: "#6741ff",
        textDecoration: "underline",
        fontWeight: "600",
        ...spacingDefaults,
      },
      render: ({ text, href, target, ...props }) => (
        <a
          href={href || "#"}
          target={target}
          rel={target === "_blank" ? "noopener noreferrer" : undefined}
          style={{
            ...buildElementStyle(props),
            display: "inline-block",
          }}
        >
          {text}
        </a>
      ),
    },

    Image: {
      label: "Image",
      fields: {
        src: textField("Image URL"),
        alt: textField("Alternative text"),
        caption: textField("Caption"),
        width: selectField("Width", WIDTH_OPTIONS),
        height: numberField("Height (px)", 0, 2000),
        objectFit: selectField("Image fit", OBJECT_FIT_OPTIONS),
        objectPosition: selectField("Image position", [
          { label: "Center", value: "center" },
          { label: "Top", value: "top" },
          { label: "Bottom", value: "bottom" },
          { label: "Left", value: "left" },
          { label: "Right", value: "right" },
        ]),
        borderRadius: numberField("Corner radius (px)", 0, 200),
        opacity: numberField("Opacity (%)", 0, 100),
        ...spacingFields,
      },
      defaultProps: {
        src: "https://placehold.co/1200x700?text=Your+Image",
        alt: "Website image",
        caption: "",
        width: "100%",
        height: 0,
        objectFit: "cover",
        objectPosition: "center",
        borderRadius: 12,
        opacity: 100,
        ...spacingDefaults,
      },
      render: ({
        src,
        alt,
        caption,
        width,
        height,
        objectFit,
        objectPosition,
        borderRadius,
        opacity,
        ...spacing
      }) => (
        <figure
          style={{
            ...buildBoxStyle(spacing),
            width,
            margin: 0,
            marginTop: spacing.marginTop,
            marginBottom: spacing.marginBottom,
          }}
        >
          <img
            src={src || "https://placehold.co/1200x700?text=Add+an+image"}
            alt={alt || ""}
            loading="lazy"
            style={{
              display: "block",
              width: "100%",
              height: height > 0 ? `${height}px` : "auto",
              objectFit,
              objectPosition,
              borderRadius: `${borderRadius}px`,
              opacity: opacity / 100,
            }}
          />
          {caption ? (
            <figcaption
              style={{
                marginTop: 8,
                color: "#737373",
                fontSize: 13,
              }}
            >
              {caption}
            </figcaption>
          ) : null}
        </figure>
      ),
    },

    
Container: {
  label: "Container",
  fields: {
    content: { type: "slot" },
    ...spacingFields,
    ...boxStyleFields,
    display: selectField("Display mode", DISPLAY_OPTIONS),
    flexDirection: selectField("Flex direction", FLEX_DIRECTION_OPTIONS),
    justifyContent: selectField("Justify content", JUSTIFY_OPTIONS),
    alignItems: selectField("Align items", ALIGN_ITEMS_OPTIONS),
    gap: numberField("Gap (px)", 0, 200),
    overflow: selectField("Overflow", [
      { label: "Visible", value: "visible" },
      { label: "Hidden", value: "hidden" },
      { label: "Auto", value: "auto" },
    ]),
  },
  defaultProps: {
    content: [],
    ...commonDesignDefaults,
    backgroundColor: "#f8fafc",
    paddingTop: "24px",
    paddingRight: "24px",
    paddingBottom: "24px",
    paddingLeft: "24px",
    borderRadius: 12,
    minHeight: 80,
    display: "flex",
    flexDirection: "column",
    justifyContent: "flex-start",
    alignItems: "stretch",
    gap: 16,
    overflow: "visible",
  },
  render: ({
    content: Content,
    display,
    flexDirection,
    justifyContent,
    alignItems,
    gap,
    overflow,
    ...props
  }) => (
    <div
      style={{
        ...buildBoxStyle(props),
        display,
        flexDirection: display === "flex" ? flexDirection : undefined,
        justifyContent: display === "flex" ? justifyContent : undefined,
        alignItems: display === "flex" ? alignItems : undefined,
        gap: `${gap}px`,
        overflow,
        minWidth: 0,
      }}
    >
      <Content
        style={{
          display: "flex",
          flexDirection: "column",
          gap: `${gap}px`,
          minWidth: 0,
          width: "100%",
        }}
        minEmptyHeight="80px"
      />
    </div>
  ),
},


    
Columns: {
  label: "Columns",
  fields: {
    column1: { type: "slot" },
    column2: { type: "slot" },
    column3: { type: "slot" },
    column4: { type: "slot" },
    columns: selectField("Grid columns", [
      { label: "2 columns", value: "2" },
      { label: "3 columns", value: "3" },
      { label: "4 columns", value: "4" },
    ]),
    gap: numberField("Column gap (px)", 0, 200),
    alignItems: selectField("Vertical alignment", ALIGN_ITEMS_OPTIONS),
    ...spacingFields,
    ...boxStyleFields,
  },
  defaultProps: {
    column1: [],
    column2: [],
    column3: [],
    column4: [],
    columns: "2",
    gap: 24,
    alignItems: "stretch",
    ...commonDesignDefaults,
    backgroundColor: "transparent",
  },
  render: ({
    column1: Column1,
    column2: Column2,
    column3: Column3,
    column4: Column4,
    columns,
    gap,
    alignItems,
    ...props
  }) => (
    <div
      style={{
        ...buildBoxStyle(props),
        display: "grid",
        gridTemplateColumns:
          `repeat(${Math.min(4, Math.max(2, Number(columns) || 2))}, minmax(0, 1fr))`,
        alignItems,
        gap: `${gap}px`,
      }}
    >
      {[Column1, Column2, Column3, Column4].map((Column, index) => (
        <div
          key={index}
          style={{
            minWidth: 0,
            gridColumn: index < Number(columns) ? undefined : "auto",
          }}
        >
          <Column minEmptyHeight="100px" />
        </div>
      ))}
    </div>
  ),
},


    Spacer: {
      label: "Spacer",
      fields: {
        height: numberField("Height (px)", 0, 600),
      },
      defaultProps: {
        height: 32,
      },
      render: ({ height }) => (
        <div
          aria-hidden="true"
          style={{
            height: `${height}px`,
            width: "100%",
            pointerEvents: "none",
          }}
        />
      ),
    },

    Divider: {
      label: "Divider",
      fields: {
        color: textField("Line color"),
        thickness: numberField("Thickness (px)", 1, 30),
        width: selectField("Width", WIDTH_OPTIONS),
        style: selectField("Line style", BORDER_STYLE_OPTIONS),
        marginTop: selectField("Margin top", SPACING_OPTIONS),
        marginBottom: selectField("Margin bottom", SPACING_OPTIONS),
      },
      defaultProps: {
        color: "#e5e7eb",
        thickness: 1,
        width: "100%",
        style: "solid",
        marginTop: "16px",
        marginBottom: "16px",
      },
      render: ({
        color,
        thickness,
        width,
        style,
        marginTop,
        marginBottom,
      }) => (
        <hr
          style={{
            width,
            border: 0,
            borderTop: `${thickness}px ${style} ${color}`,
            marginTop,
            marginBottom,
          }}
        />
      ),
    },

    Badge: {
      label: "Badge",
      fields: {
        text: textField("Badge text"),
        backgroundColor: textField("Background color"),
        color: textField("Text color"),
        fontSize: numberField("Font size (px)", 8, 32),
        paddingY: numberField("Vertical padding (px)", 0, 40),
        paddingX: numberField("Horizontal padding (px)", 0, 60),
        borderRadius: numberField("Corner radius (px)", 0, 100),
      },
      defaultProps: {
        text: "New",
        backgroundColor: "#ede9fe",
        color: "#5b21b6",
        fontSize: 12,
        paddingY: 6,
        paddingX: 12,
        borderRadius: 999,
      },
      render: ({
        text,
        backgroundColor,
        color,
        fontSize,
        paddingY,
        paddingX,
        borderRadius,
      }) => (
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            backgroundColor,
            color,
            fontSize: `${fontSize}px`,
            padding: `${paddingY}px ${paddingX}px`,
            borderRadius: `${borderRadius}px`,
            fontWeight: 600,
          }}
        >
          {text}
        </span>
      ),
    },

    List: {
      label: "List",
      fields: {
        items: {
          type: "array",
          label: "List items",
          arrayFields: {
            text: textField("Item text"),
          },
          defaultItemProps: {
            text: "New list item",
          },
          getItemSummary: (item) => item.text || "List item",
        },
        listType: selectField("List style", [
          { label: "Bullets", value: "ul" },
          { label: "Numbers", value: "ol" },
        ]),
        color: textField("Text color"),
        fontSize: numberField("Font size (px)", 8, 48),
        lineHeight: numberField("Line height", 0.5, 4),
        gap: numberField("Item spacing (px)", 0, 80),
      },
      defaultProps: {
        items: [
          { text: "First item" },
          { text: "Second item" },
          { text: "Third item" },
        ],
        listType: "ul",
        color: "#404040",
        fontSize: 16,
        lineHeight: 1.7,
        gap: 8,
      },
      render: ({ items, listType, color, fontSize, lineHeight, gap }) => {
        const Tag = listType === "ol" ? "ol" : "ul";

        return (
          <Tag
            style={{
              color,
              fontSize: `${fontSize}px`,
              lineHeight,
              paddingLeft: 24,
              margin: "12px 0",
            }}
          >
            {(items || []).map((item, index) => (
              <li key={index} style={{ marginBottom: `${gap}px` }}>
                {item.text}
              </li>
            ))}
          </Tag>
        );
      },
    },

    Card: {
      label: "Card",
      fields: {
        title: textField("Card title"),
        description: textareaField("Card description"),
        backgroundColor: textField("Background color"),
        titleColor: textField("Title color"),
        descriptionColor: textField("Description color"),
        padding: numberField("Padding (px)", 0, 120),
        borderRadius: numberField("Corner radius (px)", 0, 100),
        borderColor: textField("Border color"),
        borderWidth: numberField("Border width (px)", 0, 20),
        boxShadow: textField("Box shadow (CSS)"),
      },
      defaultProps: {
        title: "Card title",
        description: "Describe a service, feature, product, or idea.",
        backgroundColor: "#ffffff",
        titleColor: "#171717",
        descriptionColor: "#525252",
        padding: 24,
        borderRadius: 16,
        borderColor: "#e5e7eb",
        borderWidth: 1,
        boxShadow: "0 4px 16px rgba(0,0,0,0.05)",
      },
      render: ({
        title,
        description,
        backgroundColor,
        titleColor,
        descriptionColor,
        padding,
        borderRadius,
        borderColor,
        borderWidth,
        boxShadow,
      }) => (
        <article
          style={{
            boxSizing: "border-box",
            backgroundColor,
            padding,
            borderRadius,
            border: `${borderWidth}px solid ${borderColor}`,
            boxShadow: boxShadow || undefined,
          }}
        >
          <h3
            style={{
              color: titleColor,
              fontSize: 22,
              lineHeight: 1.3,
              margin: "0 0 12px",
            }}
          >
            {title}
          </h3>
          <p
            style={{
              color: descriptionColor,
              fontSize: 15,
              lineHeight: 1.7,
              margin: 0,
            }}
          >
            {description}
          </p>
        </article>
      ),
    },
  },
};

export default puckConfig;
